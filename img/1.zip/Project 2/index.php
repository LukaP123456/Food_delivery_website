<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Szeminariumi munka Internet technologiabol">
    <meta name="author" content="Liscsevity Csaba">
    <meta name="keywords" content="Szeminariumi Munka,Önéletrajz,Személyes adatok,email">
    <meta name="robots" content="index,follow">
    <title>index</title>
    <link type="text/css" rel="stylesheet" href="Oldal0c.css">
</head>
<body>
<h1 id="kfejlec">HELLO WELCOME TO MY WEBSITE </h1>
<h2 id="kfejlec2">ÜDVÖZÖLLEK AZ OLDALON</h2>
<h3 id="kfejlec3">LCS WEBSITE</h3>
<div id="kcontainer">
    <div class="nav">
        <a  class="szemelyesadatok" href="Oldal1.html">Szemelyes adatok</a>
        <a  class="kedvenclinkek" href="Oldal2.html">Kedvenc linkek</a>
        <a  class="kedvencfilmek" href="Oldal3.html">Kedvenc filmek</a>
    </div>
</div>
<div id="ido">
    <?php
    echo Date("Y.m.d.");
    ?>
    <div class="footer">
        <p>© 2018 Liscsevity Csaba All Rights Reserved.</p>
    </div>
</div>
</body>
</html>