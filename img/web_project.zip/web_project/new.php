<div id="content">
   <h1>New product</h1>
</div>
