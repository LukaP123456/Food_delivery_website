<div id="navigation">
    <ol>
        <li><a href="index.php">Home</a></li>
        <li><a href="index.php?op=new">New</a></li>
        <li><a href="index.php?op=list">List</a></li>
        <li><a href="index.php?op=update">Update</a></li>
        <li><a href="index.php?op=delete">Delete</a></li>
    </ol>
</div>
